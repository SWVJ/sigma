#include "DHT.h"

#define DHTPIN 3
#define DHTTYPE DHT11

DHT dht(DHTPIN, DHTTYPE);

void setup()
{
  Serial.begin(9600);
  dht.begin();
  Serial.println("Weather Station Initialized");
}

void loop()
{
  float temp = dht.readTemperature();
  float hum = dht.readHumidity();

  // Check if readings failed and exit early to try again
  if (isnan(temp) || isnan(hum))
  {
    Serial.println("Failed to read from DHT sensor!");
    return;
  }

  // Print Temperature
  Serial.print("Temperature: ");
  Serial.print(temp);
  Serial.println(" °C");

  // Print Humidity
  Serial.print("Humidity: ");
  Serial.print(hum);
  Serial.println(" %");

  Serial.println("-----------------");
  delay(2000); // Wait 2 seconds between readings
}