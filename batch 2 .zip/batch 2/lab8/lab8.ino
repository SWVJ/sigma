const int gasSensorPin = A0; // Connect MQ-2 / gas sensor analog output to A0
const int buzzerPin = 8;     // Connect buzzer positive terminal to Digital Pin 8
int gasLevel = 0;            // Variable to store sensor readings
int threshold = 30;         // Sensitivity threshold level

void setup()
{
  // Note: pinMode is NOT required for analog pins like A0
  pinMode(buzzerPin, OUTPUT);
  Serial.begin(9600);          // Initialize serial communication
}

void loop()
{
  // Read the analog value from the gas sensor
  gasLevel = analogRead(gasSensorPin);
  
  // Print current gas level to the Serial Monitor
  Serial.print("Gas Level: ");
  Serial.println(gasLevel);
  
  // Check if the gas level exceeds the safety threshold
  if (gasLevel > threshold)
  {
    digitalWrite(buzzerPin, HIGH);             // Turn ON buzzer alarm
    Serial.println("Gas Leak Detected!");      // Print warning message
  }
  else
  {
    digitalWrite(buzzerPin, LOW);              // Turn OFF buzzer alarm
  }
  
  delay(1000); // Wait 1 second before next reading
}