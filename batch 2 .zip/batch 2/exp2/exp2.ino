// Define the digital pin connected to the relay module's IN pin
const int relayPin = 7;

void setup() {
  // Initialize the relay pin as an output
  pinMode(relayPin, OUTPUT);
}

void loop() {
  // Turn the relay ON (closes the switch / activates module)
  digitalWrite(relayPin, HIGH); 
  delay(2000);                  // Keep it ON for 2 seconds

  // Turn the relay OFF (opens the switch / deactivates module)
  digitalWrite(relayPin, LOW);  
  delay(2000);                  // Keep it OFF for 2 seconds
}