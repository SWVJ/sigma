// Define the pin numbers for the 5 LEDs
int ledPins[] = {2, 3, 4, 5, 6}; 

void setup() {
  // Set all 5 pins as OUTPUT using a loop
  for (int i = 0; i < 5; i++) {
    pinMode(ledPins[i], OUTPUT);
  }
}

void loop() {
  // Forward direction: LED 1 to LED 5
  for (int i = 0; i < 5; i++) {
    digitalWrite(ledPins[i], HIGH);  // Turn current LED ON
    delay(2000);                      // Short delay for visual effect
    digitalWrite(ledPins[i], LOW);   // Turn current LED OFF
  }

  // Backward direction: LED 4 down to LED 2 (skipping endpoints to bounce back cleanly)
  for (int i = 3; i > 0; i--) {
    digitalWrite(ledPins[i], HIGH);  // Turn current LED ON
    delay(200);
    digitalWrite(ledPins[i], LOW);   // Turn current LED OFF
  }
}