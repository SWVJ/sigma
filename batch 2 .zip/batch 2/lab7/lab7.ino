#define PH_PIN A0

float voltage, phValue;

// Custom map function for floating point numbers
float fmap(float x, float in_min, float in_max, float out_min, float out_max) {
  return (x - in_min) * (out_max - out_min) / (in_max - in_min) + out_min;
}

void setup() {
  // Set to standard Uno baud rate
  Serial.begin(9600); 
}

void loop() {
  // Use static to initialize only once
  static unsigned long timepoint = millis();
  
  // Use 1000UL for Unsigned Long comparison
  if (millis() - timepoint > 1000UL) { 
    timepoint = millis();
    
    // Divide by 1023.0 for accurate 10-bit ADC conversion
    voltage = analogRead(PH_PIN) / 1023.0 * 5.0;
    
    // Map the voltage to pH based on calibration values
    phValue = fmap(voltage, 3.90, 4.50, 6.5, 8.5);
    
    Serial.print("pH level: ");
    Serial.println(phValue, 2);
  }
}