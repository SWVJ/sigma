const int ldrDigitalPin = 7;
const int lightPin = 11;

void setup()
{
  pinMode(ldrDigitalPin, INPUT);
  pinMode(lightPin, OUTPUT);
  Serial.begin(9600);
}

void loop()
{
  int ldrState = digitalRead(ldrDigitalPin);
  
  Serial.print("LDR state: ");
  Serial.println(ldrState);
  
  if (ldrState == LOW)
  {
    digitalWrite(lightPin, HIGH);
  }
  else
  {
    digitalWrite(lightPin, LOW);
  }
  
  delay(500);
}