const int moisturePin = A0;
int moistureValue = 0;
const int threshold = 400;

void setup() {
  Serial.begin(9600);
  pinMode(moisturePin, INPUT);
}

void loop() {
  moistureValue = analogRead(moisturePin);
  Serial.print("Moisture Value: ");
  Serial.println(moistureValue);
  
  if (moistureValue < threshold) {
    Serial.println("Dry waste Detected");
  } else {
    Serial.println("Wet waste Detected");
  }
  
  delay(1000);
}