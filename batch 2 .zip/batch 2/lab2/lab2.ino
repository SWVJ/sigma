const int relayPin = 7; 
const int led = 5;
void setup() 
{
    pinMode(relayPin, OUTPUT);  
    pinMode(led, OUTPUT);
    digitalWrite(relayPin, LOW); 
}
void loop()
{
    digitalWrite(relayPin, HIGH); 
    digitalWrite(led, HIGH); 
    delay(500);                 
    digitalWrite(relayPin, LOW);  
    digitalWrite(led, LOW); 
    delay(2000);                  
}