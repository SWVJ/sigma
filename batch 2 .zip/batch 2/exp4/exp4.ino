const int in1 = 8;
const int in2 = 9;
const int led = 2;

void setup()
{
  pinMode(in1, OUTPUT);
  pinMode(in2, OUTPUT);
  pinMode(led, OUTPUT);  // Added correct pinMode initialization for the indicator LED
}

void loop()
{
  // Motor rotates in Forward direction, LED turns ON
  digitalWrite(in1, HIGH);
  digitalWrite(in2, LOW);
  digitalWrite(led, HIGH);
  delay(500);
  
  // Motor rotates in Reverse direction, LED turns OFF
  digitalWrite(in1, LOW);
  digitalWrite(in2, HIGH);
  digitalWrite(led, LOW);
  delay(1000);
}